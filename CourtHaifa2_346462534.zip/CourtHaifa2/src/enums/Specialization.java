package enums;

public enum Specialization {
	criminal ,
	damages ,
	traffic ,
	family ,
	realEstate ,
	contractLaw ,
	copyright ,
	medicalMalpractice ;

}
