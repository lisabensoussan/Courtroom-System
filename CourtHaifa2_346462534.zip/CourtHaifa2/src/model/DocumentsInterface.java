package model;

public interface DocumentsInterface {
	public Document getRequiredDocument();

}
