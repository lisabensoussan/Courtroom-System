package model;

public interface CasesInterface {
	public Case getRequiredCase();

}
